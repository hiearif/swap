function index() {
  return <div className="text-red-100">index</div>;
}

export default index;
